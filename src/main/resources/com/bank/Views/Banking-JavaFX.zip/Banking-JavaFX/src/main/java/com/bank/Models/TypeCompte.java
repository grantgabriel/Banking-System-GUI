package com.bank.Models;

public enum TypeCompte {
    EPARGNE, COURANT

    }
