package com.bank.Models;

public enum Devise {
    TND,
    EUR,
    DOL
}
