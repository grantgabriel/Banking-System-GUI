package includes;

public class Saldo {
    private int id;
    private int id_user;
    private int saldo;

    public Saldo(int id, int id_user, int saldo){
        this.id = id;
        this.id_user = id_user;
        this.saldo = saldo;
    }

    public Saldo(){

    }

    public int getId(){
        return id;
    }

    public int getIdUser(){
        return id_user;
    }

    public int getSaldo(){
        return saldo;
    }

    public void setId(int id){
        this.id = id;
    }

    public void setIdUser(int id_user){
        this.id_user = id_user;
    }

    public void setSaldo(int saldo){
        this.saldo = saldo;
    }
}
