package Components;

import javax.swing.*;
import java.awt.*;

public class Frame extends JFrame {

    public Frame(){
        ImageIcon icon = new ImageIcon("src/assets/icon.png");
        this.setIconImage(icon.getImage());
    }

}
